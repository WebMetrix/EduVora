# EduVora CI/CD Pipeline Setup Guide (GitHub Actions + Windows IIS + PM2)

This guide walks through setting up a **100% free** CI/CD pipeline for `webmetrix/eduvora` using **GitHub Actions with a self-hosted Windows runner** installed directly on your IIS server. According to [GitHub Actions Billing & Usage](https://docs.github.com/en/actions/concepts/billing-and-usage), self-hosted runners incur **zero GitHub Actions minute charges** on both public and private repositories, and running on the IIS server itself avoids opening inbound WinRM or Web Deploy ports.

## Architecture Overview

| Component | Tech Stack | Hosting Method | Default QA Path | Default Prod Path | 
| ----- | ----- | ----- | ----- | ----- | 
| `frontend` | React 19 + Vite 8 | IIS Static Site + URL Rewrite SPA fallback | `C:\inetpub\EduVora\QA\frontend` | `C:\inetpub\EduVora\Prod\frontend` | 
| `admin_frontend` | React 19 + Vite 8 | IIS Static Site + URL Rewrite SPA fallback | `C:\inetpub\EduVora\QA\admin_frontend` | `C:\inetpub\EduVora\Prod\admin_frontend` | 
| `backend` | Node.js Express 5 (ESM) | PM2 (`ecosystem.config.cjs`) behind IIS ARR Reverse Proxy | `C:\inetpub\EduVora\QA\backend` (port `5001`) | `C:\inetpub\EduVora\Prod\backend` (port `5000`) | 
| `kyc-python-worker` | Python + Celery + OpenCV | Native Windows Service (`EduVoraKYCValidator*`) | `C:\inetpub\EduVora\QA\Services\KYCValidator` | `C:\inetpub\EduVora\Prod\Services\KYCValidator` | 
| `audiobook-worker` | Python + Celery + Edge-TTS | Native Windows Service (`EduVoraAudiobookWorker*`) | `C:\inetpub\EduVora\QA\Services\AudiobookWorker` | `C:\inetpub\EduVora\Prod\Services\AudiobookWorker` | 

## 1. Add the Pipeline Files to Your Repository

Extract `eduvora-iis-cicd.zip` directly into the root of your `webmetrix/eduvora` repository so the files sit at:

* `.github/workflows/ci-cd-iis.yml`

* `deploy/iis/frontend-web.config`

* `deploy/iis/admin-frontend-web.config`

* `deploy/iis/backend-web.config.template`

* `deploy/pm2/ecosystem.config.cjs`

* `deploy/scripts/setup-server.ps1`

* `deploy/scripts/deploy-all.ps1`

* `deploy/CI_CD_IIS_SETUP.md`

Commit and push these files to your `qa` (and later `main`) branch.

## 2. One-Time Windows Server Prerequisites

Install the following on your Windows/IIS server:

1. **IIS with URL Rewrite + ARR**:

   * Install [IIS URL Rewrite Module 2.1](https://www.iis.net/downloads/microsoft/url-rewrite) and [Microsoft Application Request Routing (ARR) 3.0](https://www.microsoft.com/en-us/download/details.aspx?id=47333).

   * Reference walkthrough: [Reverse Proxy with URL Rewrite v2 and ARR (Microsoft Learn)](https://learn.microsoft.com/en-us/iis/extensions/url-rewrite-module/reverse-proxy-with-url-rewrite-v2-and-application-request-routing).

2. **Node.js (LTS 20+ or 22+) & PM2**:

   ```
   npm install -g pm2 pm2-windows-startup
   pm2-startup install
   
   ```

   Running `pm2-startup install` ensures PM2 automatically resurrects your saved `eduvora-backend-*` processes after a Windows Server reboot.

3. **Python 3.10+** (added to system `PATH`) + **Tesseract OCR** (required by `pytesseract` in `kyc-python-worker`) + **ODBC Driver for SQL Server** (required by `pyodbc`).

4. **PowerShell 7 (`pwsh`)**: Ensure `pwsh` is installed and in `PATH` (used by the GitHub Actions workflow steps).

## 3. Bootstrap IIS Sites and Folders

Open an **elevated PowerShell** window (Run as Administrator) on the server and run `setup-server.ps1` once per environment:

```
# QA environment
.\deploy\scripts\setup-server.ps1 `
  -Environment qa `
  -DeployRoot "C:\inetpub\EduVora\QA" `
  -FrontendSite "EduVora-Frontend-QA" `
  -AdminSite "EduVora-Admin-QA" `
  -BackendSite "EduVora-API-QA" `
  -FrontendHost "eduvoraqa.eduvora.co.in" `
  -AdminHost "adminqa.eduvora.co.in" `
  -ApiHost "apiqa.eduvora.co.in"

# Production environment (when ready)
.\deploy\scripts\setup-server.ps1 `
  -Environment production `
  -DeployRoot "C:\inetpub\EduVora\Prod" `
  -FrontendSite "EduVora-Frontend-Prod" `
  -AdminSite "EduVora-Admin-Prod" `
  -BackendSite "EduVora-API-Prod" `
  -FrontendHost "eduvora.co.in" `
  -AdminHost "admin.eduvora.co.in" `
  -ApiHost "api.eduvora.co.in"

```

This creates the directory structure, sets up dedicated `No Managed Code` IIS Application Pools and Sites, enables ARR Server Proxy, and adds `HTTP_X_FORWARDED_PROTO` to IIS `allowedServerVariables` (preventing HTTP 500.50 errors on reverse-proxied requests).

Next, place your server-side `.env` files in:

* `C:\inetpub\EduVora\<Env>\backend\.env` (set `PORT=5001` for QA or `PORT=5000` for Prod, plus your DB, RabbitMQ, Cashfree, JWT, SMTP, and path variables)

* `C:\inetpub\EduVora\<Env>\Services\KYCValidator\.env`

* `C:\inetpub\EduVora\<Env>\Services\AudiobookWorker\.env`

The deployment script explicitly excludes `.env`, `App_Data`, `logs`, and `.venv` during every deployment so your server secrets and virtual environments are never overwritten.

## 4. Install the GitHub Actions Self-Hosted Runner

Follow [GitHub Docs: Self-hosted runners](https://docs.github.com/en/actions/concepts/runners/self-hosted-runners):

1. In GitHub, open **`webmetrix/eduvora` → Settings → Actions → Runners → New self-hosted runner**.

2. Select **Windows** and **x64**.

3. Run the download and `config.cmd` commands in an **Administrator PowerShell** prompt on your IIS server (for example under `C:\actions-runner`).

4. When prompted **"Would you like to run the runner as a service?"**, choose **Y** and run it under an account with local **Administrator** privileges (required to copy into `C:\inetpub`, reload PM2, and stop/start Windows Services).

## 5. Configure GitHub Environments, Variables, and Secrets

In GitHub, go to **Settings → Environments** and create two environments: **`qa`** and **`production`**.

### Environment Variables (`Settings → Environments → <env> → Environment variables`)

| Variable | Example (QA) | Example (Prod) | Required? | 
| ----- | ----- | ----- | ----- | 
| `VITE_API_URL` | `https://apiqa.eduvora.co.in` | `https://api.eduvora.co.in` | Yes | 
| `ADMIN_VITE_API_URL` | `https://apiqa.eduvora.co.in` | `https://api.eduvora.co.in` | Optional (falls back to `VITE_API_URL`) | 
| `VITE_REFERRAL_URL` | `https://eduvoraqa.eduvora.co.in` | `https://eduvora.co.in` | Yes | 
| `VITE_FALLBACK_PROF_PICTURE` | `https://ui-avatars.com/api/?name=` | `https://ui-avatars.com/api/?name=` | Yes | 
| `VITE_MIN_WITHDRAWAL_AMOUNT` | `500` | `500` | Yes | 
| `DEPLOY_ROOT` | `C:\inetpub\EduVora\QA` | `C:\inetpub\EduVora\Prod` | Optional (has defaults) | 
| `BACKEND_PORT` | `5001` | `5000` | Optional (has defaults) | 

### Environment Secrets (`Settings → Environments → <env> → Environment secrets`)

| Secret | Used By | 
| ----- | ----- | 
| `VITE_GOOGLE_CLIENT_ID` | `frontend` build (`GoogleOAuthProvider`) | 
| `VITE_CRYPTO_SECRET` | `frontend` build (`LoginForm.jsx`) | 

## 6. Triggering and Verifying Deployments

* **Automatic deploys:** Pushing to `qa` deploys all five components to QA; pushing to `main` deploys all five to Production.

* **Single-component or manual deploys:** Go to **Actions → EduVora CI/CD to Windows IIS → Run workflow**, pick `qa` or `production`, and choose either `all` or a single component (`frontend`, `admin_frontend`, `backend`, `kyc-python-worker`, or `audiobook-worker`).

* **Verification commands on the server:**

  ```
  pm2 status
  pm2 logs eduvora-backend-qa --lines 50
  Get-Service EduVoraKYCValidatorQA, EduVoraAudiobookWorkerQA
  
  ```

## Important Codebase Notes Handled by This Pipeline

* **PM2 ESM compatibility:** Because `backend/package.json` sets `"type": "module"`, PM2 requires a `.cjs` config file (`ecosystem.config.cjs`).

* **KYC worker path & venv isolation:** `kyc-python-worker/windows_service.py` originally hardcoded `C:\inetpub\EduVora\Services\KYCValidator` and `run_worker.bat` called global `python`. `deploy-all.ps1` automatically patches both at deploy time so QA and Prod can coexist cleanly on the same server with isolated `.venv` environments.

* **Upload size limits:** `backend-web.config.template` raises IIS `maxAllowedContentLength` to `100 MB` so Multer uploads (KYC documents, avatars, and chapter PDFs) are not rejected by IIS's default 30 MB limit.