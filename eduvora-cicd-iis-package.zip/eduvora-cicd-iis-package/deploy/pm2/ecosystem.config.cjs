// Note: .cjs extension is required because backend/package.json uses "type": "module" (ESM).
module.exports = {
  apps: [
    {
      name: process.env.PM2_APP_NAME || "eduvora-backend-qa",
      script: "app.js",
      cwd: process.env.BACKEND_DIR || "C:\\inetpub\\EduVora\\QA\\backend",
      exec_mode: "fork",
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: "1G",
      env: {
        NODE_ENV: process.env.NODE_ENV || "development",
        PORT: process.env.PORT || "5001"
      },
      env_qa: {
        NODE_ENV: "qa",
        PORT: process.env.PORT || "5001"
      },
      env_production: {
        NODE_ENV: "production",
        PORT: process.env.PORT || "5000"
      },
      out_file: (process.env.BACKEND_DIR || "C:\\inetpub\\EduVora\\QA\\backend") + "\\logs\\pm2-out.log",
      error_file: (process.env.BACKEND_DIR || "C:\\inetpub\\EduVora\\QA\\backend") + "\\logs\\pm2-error.log",
      merge_logs: true,
      time: true
    }
  ]
};
