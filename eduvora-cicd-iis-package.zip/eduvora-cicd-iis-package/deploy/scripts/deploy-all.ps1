<#
.SYNOPSIS
    Idempotent deployment script for all 5 EduVora components on Windows Server:
      1. frontend          -> IIS static SPA + URL Rewrite web.config
      2. admin_frontend    -> IIS static SPA + URL Rewrite web.config
      3. backend           -> Node.js Express 5 ESM managed by PM2 + IIS ARR Reverse Proxy web.config
      4. kyc-python-worker -> Python Celery native Windows Service (EduVoraKYCValidator*)
      5. audiobook-worker  -> Python Celery native Windows Service (EduVoraAudiobookWorker*)
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$SourceRoot,

    [Parameter(Mandatory = $true)]
    [string]$DeployRoot,

    [ValidateSet("qa", "production")]
    [string]$Environment = "qa",

    [ValidateSet("all", "frontend", "admin_frontend", "backend", "kyc-python-worker", "audiobook-worker")]
    [string]$Component = "all",

    [int]$BackendPort = 5001,
    [string]$Pm2AppName = "eduvora-backend-qa",
    [string]$IisFrontendSite = "EduVora-Frontend-QA",
    [string]$IisAdminSite = "EduVora-Admin-QA",
    [string]$IisBackendSite = "EduVora-API-QA",
    [string]$KycServiceName = "EduVoraKYCValidatorQA",
    [string]$AudiobookServiceName = "EduVoraAudiobookWorkerQA"
)

$ErrorActionPreference = "Stop"

function Invoke-RobocopyMirror {
    param(
        [string]$Source,
        [string]$Destination,
        [string[]]$ExcludeDirs = @(),
        [string[]]$ExcludeFiles = @()
    )

    if (-not (Test-Path $Destination)) {
        New-Item -ItemType Directory -Path $Destination -Force | Out-Null
    }

    $argsList = @($Source, $Destination, "/MIR", "/R:3", "/W:2", "/NFL", "/NDL", "/NP")
    if ($ExcludeDirs.Count -gt 0) {
        $argsList += "/XD"
        $argsList += $ExcludeDirs
    }
    if ($ExcludeFiles.Count -gt 0) {
        $argsList += "/XF"
        $argsList += $ExcludeFiles
    }

    & robocopy @argsList | Out-Host
    # Robocopy exit codes 0-7 indicate success; 8+ indicate errors
    if ($LASTEXITCODE -ge 8) {
        throw "Robocopy failed with exit code $LASTEXITCODE ($Source -> $Destination)"
    }
    $global:LASTEXITCODE = 0
}

function Stop-WinServiceSafe {
    param([string]$ServiceName)
    $svc = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    if ($null -ne $svc) {
        if ($svc.Status -ne "Stopped") {
            Write-Host "Stopping Windows Service '$ServiceName'..."
            Stop-Service -Name $ServiceName -Force -ErrorAction Stop
            $svc.WaitForStatus("Stopped", [TimeSpan]::FromSeconds(30))
        }
        return $true
    }
    return $false
}

function Start-WinServiceSafe {
    param([string]$ServiceName)
    Write-Host "Starting Windows Service '$ServiceName'..."
    Start-Service -Name $ServiceName -ErrorAction Stop
    $svc = Get-Service -Name $ServiceName
    $svc.WaitForStatus("Running", [TimeSpan]::FromSeconds(30))
    Write-Host "[OK] Windows Service '$ServiceName' is Running." -ForegroundColor Green
}

function Deploy-StaticSpa {
    param(
        [string]$Label,
        [string]$DistPath,
        [string]$TargetDir,
        [string]$WebConfigSource
    )

    Write-Host "`n=== Deploying $Label -> $TargetDir ===" -ForegroundColor Cyan
    if (-not (Test-Path $DistPath)) {
        throw "Build output not found at $DistPath. Ensure 'npm run build' ran before deploy."
    }

    Invoke-RobocopyMirror -Source $DistPath -Destination $TargetDir -ExcludeFiles @("web.config")
    Copy-Item -Path $WebConfigSource -Destination (Join-Path $TargetDir "web.config") -Force
    Write-Host "[OK] $Label deployed with IIS web.config." -ForegroundColor Green
}

function Deploy-Backend {
    $srcDir = Join-Path $SourceRoot "backend"
    $dstDir = Join-Path $DeployRoot "backend"
    Write-Host "`n=== Deploying Backend (PM2 + IIS Reverse Proxy) -> $dstDir ===" -ForegroundColor Cyan

    if (-not (Test-Path (Join-Path $dstDir ".env"))) {
        Write-Warning "No .env file found at $dstDir\.env. Create it on the server with DB, RabbitMQ, Cashfree, JWT, and PORT=$BackendPort settings."
    }

    # Preserve server-side secrets, runtime uploads, logs, and node_modules during sync
    Invoke-RobocopyMirror -Source $srcDir -Destination $dstDir `
        -ExcludeDirs @("node_modules", "logs", "App_Data", ".git") `
        -ExcludeFiles @(".env", "web.config", "ecosystem.config.cjs")

    # Install production dependencies
    Push-Location $dstDir
    try {
        Write-Host "Installing production npm dependencies..."
        npm ci --omit=dev
        if ($LASTEXITCODE -ne 0) { throw "npm ci --omit=dev failed in $dstDir" }
    } finally {
        Pop-Location
    }

    # Render IIS reverse-proxy web.config with target port
    $tplPath = Join-Path $SourceRoot "deploy\iis\backend-web.config.template"
    $webConfigContent = (Get-Content -Path $tplPath -Raw).Replace("__BACKEND_PORT__", $BackendPort.ToString())
    Set-Content -Path (Join-Path $dstDir "web.config") -Value $webConfigContent -Encoding UTF8

    # Copy PM2 ecosystem.config.cjs
    Copy-Item -Path (Join-Path $SourceRoot "deploy\pm2\ecosystem.config.cjs") `
              -Destination (Join-Path $dstDir "ecosystem.config.cjs") -Force

    # Start or reload via PM2
    $env:PM2_APP_NAME = $Pm2AppName
    $env:BACKEND_DIR  = $dstDir
    $env:PORT         = $BackendPort.ToString()
    $env:NODE_ENV     = $Environment

    Push-Location $dstDir
    try {
        $pm2EnvFlag = if ($Environment -eq "production") { "production" } else { "qa" }
        Write-Host "Reloading PM2 app '$Pm2AppName' (port $BackendPort, env $pm2EnvFlag)..."
        pm2 startOrReload ecosystem.config.cjs --env $pm2EnvFlag --update-env
        if ($LASTEXITCODE -ne 0) { throw "pm2 startOrReload failed for $Pm2AppName" }
        pm2 save
    } finally {
        Pop-Location
    }

    # Health check local Express listener
    Start-Sleep -Seconds 3
    $healthUrl = "http://127.0.0.1:$BackendPort/api-docs"
    try {
        $resp = Invoke-WebRequest -Uri $healthUrl -UseBasicParsing -TimeoutSec 10
        Write-Host "[OK] Backend health check succeeded ($healthUrl -> HTTP $($resp.StatusCode))." -ForegroundColor Green
    } catch {
        # Express responding with 401/404 still proves the server is up and accepting HTTP traffic
        if ($_.Exception.Response) {
            $code = [int]$_.Exception.Response.StatusCode
            Write-Host "[OK] Backend listener is active ($healthUrl -> HTTP $code)." -ForegroundColor Green
        } else {
            throw "Backend health check failed on $healthUrl : $($_.Exception.Message)"
        }
    }
}

function Deploy-PythonWorker {
    param(
        [string]$Label,
        [string]$SourceSubdir,
        [string]$TargetDir,
        [string]$ServiceName,
        [bool]$EnsurePyWin32 = $true,
        [bool]$PatchKycBatToVenv = $false
    )

    $srcDir = Join-Path $SourceRoot $SourceSubdir
    Write-Host "`n=== Deploying $Label ($ServiceName) -> $TargetDir ===" -ForegroundColor Cyan

    $serviceExisted = Stop-WinServiceSafe -ServiceName $ServiceName

    # Sync worker source while preserving .env, .venv, and logs
    Invoke-RobocopyMirror -Source $srcDir -Destination $TargetDir `
        -ExcludeDirs @(".venv", "venv", "logs", "__pycache__", ".git") `
        -ExcludeFiles @(".env")

    if (-not (Test-Path (Join-Path $TargetDir ".env"))) {
        Write-Warning "No .env file found at $TargetDir\.env. Worker service may fail to start until .env is created."
    }

    $venvDir   = Join-Path $TargetDir ".venv"
    $pythonExe = Join-Path $venvDir "Scripts\python.exe"

    if (-not (Test-Path $pythonExe)) {
        Write-Host "Creating Python virtual environment at $venvDir..."
        python -m venv $venvDir
        if ($LASTEXITCODE -ne 0) { throw "Failed to create Python venv at $venvDir" }
    }

    Write-Host "Installing Python dependencies from requirements.txt..."
    & $pythonExe -m pip install --upgrade pip
    & $pythonExe -m pip install -r (Join-Path $TargetDir "requirements.txt")
    if ($LASTEXITCODE -ne 0) { throw "pip install failed for $Label" }

    if ($EnsurePyWin32) {
        & $pythonExe -m pip install pywin32
        $postInstall = Join-Path $venvDir "Scripts\pywin32_postinstall.py"
        if (Test-Path $postInstall) {
            & $pythonExe $postInstall -install -silent
        }
    }

    # Ensure KYC run_worker.bat uses the isolated .venv Python and correct working directory
    if ($PatchKycBatToVenv) {
        $batPath = Join-Path $TargetDir "run_worker.bat"
        $batContent = @"
@echo off
cd /d "%~dp0"
echo Starting EduVora KYC Celery Worker...
"%~dp0.venv\Scripts\python.exe" -m celery -A worker_app.celery_app worker --loglevel=info --pool=solo --without-mingle --without-gossip
"@
        Set-Content -Path $batPath -Value $batContent -Encoding ASCII

        # Patch windows_service.py if TargetDir or ServiceName differs from hardcoded default
        $svcScript = Join-Path $TargetDir "windows_service.py"
        if (Test-Path $svcScript) {
            $pyText = Get-Content -Path $svcScript -Raw
            $pyText = $pyText -replace '_svc_name_\s*=\s*"[^"]+"', "_svc_name_ = `"$ServiceName`""
            $pyText = $pyText -replace 'r"C:\\inetpub\\EduVora\\Services\\KYCValidator\\run_worker\.bat"', "r`"$batPath`""
            $pyText = $pyText -replace 'r"C:\\inetpub\\EduVora\\Services\\KYCValidator"', "r`"$TargetDir`""
            Set-Content -Path $svcScript -Value $pyText -Encoding UTF8
        }
    }

    # Install Windows Service if not yet registered
    if (-not $serviceExisted) {
        Write-Host "Installing Windows Service '$ServiceName' for the first time..."
        Push-Location $TargetDir
        try {
            & $pythonExe (Join-Path $TargetDir "windows_service.py") --startup auto install
            if ($LASTEXITCODE -ne 0) { throw "Failed to install Windows Service $ServiceName" }
            sc.exe failure $ServiceName reset= 86400 actions= restart/10000/restart/30000/restart/60000 | Out-Null
        } finally {
            Pop-Location
        }
    }

    Start-WinServiceSafe -ServiceName $ServiceName
}

# --- Execute selected deployments ---
if ($Component -in @("all", "frontend")) {
    Deploy-StaticSpa -Label "Frontend" `
        -DistPath (Join-Path $SourceRoot "frontend\dist") `
        -TargetDir (Join-Path $DeployRoot "frontend") `
        -WebConfigSource (Join-Path $SourceRoot "deploy\iis\frontend-web.config")
}

if ($Component -in @("all", "admin_frontend")) {
    Deploy-StaticSpa -Label "Admin Frontend" `
        -DistPath (Join-Path $SourceRoot "admin_frontend\dist") `
        -TargetDir (Join-Path $DeployRoot "admin_frontend") `
        -WebConfigSource (Join-Path $SourceRoot "deploy\iis\admin-frontend-web.config")
}

if ($Component -in @("all", "backend")) {
    Deploy-Backend
}

if ($Component -in @("all", "kyc-python-worker")) {
    Deploy-PythonWorker -Label "KYC Python Worker" `
        -SourceSubdir "kyc-python-worker" `
        -TargetDir (Join-Path $DeployRoot "Services\KYCValidator") `
        -ServiceName $KycServiceName `
        -EnsurePyWin32 $true `
        -PatchKycBatToVenv $true
}

if ($Component -in @("all", "audiobook-worker")) {
    Deploy-PythonWorker -Label "Audiobook Worker" `
        -SourceSubdir "audiobook-worker" `
        -TargetDir (Join-Path $DeployRoot "Services\AudiobookWorker") `
        -ServiceName $AudiobookServiceName `
        -EnsurePyWin32 $true `
        -PatchKycBatToVenv $false
}

Write-Host "`n=== EduVora deployment ($Environment / $Component) completed successfully! ===" -ForegroundColor Green
