<#
.SYNOPSIS
    One-time Windows Server + IIS bootstrap script for EduVora (QA or Production).
    MUST be run as Administrator in PowerShell.

.EXAMPLE
    .\setup-server.ps1 -Environment qa -DeployRoot "C:\inetpub\EduVora\QA" `
        -FrontendHost "eduvoraqa.eduvora.co.in" `
        -AdminHost "adminqa.eduvora.co.in" `
        -ApiHost "apiqa.eduvora.co.in"
#>
[CmdletBinding()]
param(
    [ValidateSet("qa", "production")]
    [string]$Environment = "qa",

    [string]$DeployRoot = "C:\inetpub\EduVora\QA",

    [string]$FrontendSite = "EduVora-Frontend-QA",
    [string]$AdminSite    = "EduVora-Admin-QA",
    [string]$BackendSite  = "EduVora-API-QA",

    [string]$FrontendHost = "eduvoraqa.eduvora.co.in",
    [string]$AdminHost    = "adminqa.eduvora.co.in",
    [string]$ApiHost      = "apiqa.eduvora.co.in",

    [int]$HttpPort = 80
)

$ErrorActionPreference = "Stop"

# Verify Administrator privileges
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Please run this script in an elevated PowerShell window (Run as Administrator)."
}

Write-Host "=== Bootstrapping EduVora ($Environment) at $DeployRoot ===" -ForegroundColor Cyan

# 1. Verify required tools
foreach ($cmd in @("node", "npm", "pm2", "python")) {
    if (-not (Get-Command $cmd -ErrorAction SilentlyContinue)) {
        Write-Warning "Command '$cmd' was not found in PATH. Install it before running the CI/CD pipeline."
    } else {
        Write-Host "[OK] Found $cmd -> $((Get-Command $cmd).Source)" -ForegroundColor Green
    }
}

# 2. Create directory layout
$dirs = @(
    "$DeployRoot\frontend",
    "$DeployRoot\admin_frontend",
    "$DeployRoot\backend",
    "$DeployRoot\backend\logs",
    "$DeployRoot\backend\App_Data",
    "$DeployRoot\Services\KYCValidator",
    "$DeployRoot\Services\KYCValidator\logs",
    "$DeployRoot\Services\AudiobookWorker",
    "$DeployRoot\Services\AudiobookWorker\logs"
)
foreach ($d in $dirs) {
    if (-not (Test-Path $d)) {
        New-Item -ItemType Directory -Path $d -Force | Out-Null
        Write-Host "[CREATED] $d"
    }
}

# 3. Configure IIS Sites & AppPools
Import-Module WebAdministration

function Ensure-IisSite {
    param(
        [string]$SiteName,
        [string]$PhysicalPath,
        [string]$HostHeader,
        [int]$Port
    )

    $poolName = "$SiteName-Pool"
    if (-not (Test-Path "IIS:\AppPools\$poolName")) {
        New-WebAppPool -Name $poolName | Out-Null
        # Static SPAs and Reverse Proxy sites do not need .NET CLR
        Set-ItemProperty "IIS:\AppPools\$poolName" -Name managedRuntimeVersion -Value ""
        Write-Host "[CREATED] AppPool $poolName (No Managed Code)" -ForegroundColor Green
    }

    if (-not (Test-Path "IIS:\Sites\$SiteName")) {
        New-Website -Name $SiteName -PhysicalPath $PhysicalPath -ApplicationPool $poolName -Port $Port -HostHeader $HostHeader | Out-Null
        Write-Host "[CREATED] IIS Site $SiteName ($HostHeader`:$Port -> $PhysicalPath)" -ForegroundColor Green
    } else {
        Set-ItemProperty "IIS:\Sites\$SiteName" -Name physicalPath -Value $PhysicalPath
        Write-Host "[EXISTS]  IIS Site $SiteName updated physicalPath -> $PhysicalPath"
    }
}

Ensure-IisSite -SiteName $FrontendSite -PhysicalPath "$DeployRoot\frontend"       -HostHeader $FrontendHost -Port $HttpPort
Ensure-IisSite -SiteName $AdminSite    -PhysicalPath "$DeployRoot\admin_frontend" -HostHeader $AdminHost    -Port $HttpPort
Ensure-IisSite -SiteName $BackendSite  -PhysicalPath "$DeployRoot\backend"        -HostHeader $ApiHost      -Port $HttpPort

# 4. Enable IIS ARR Reverse Proxy & allow HTTP_X_FORWARDED_PROTO server variable
try {
    Set-WebConfigurationProperty -PSPath 'MACHINE/WEBROOT/APPHOST' -Filter "system.webServer/proxy" -Name "enabled" -Value "True"
    Write-Host "[OK] Enabled IIS ARR server proxy." -ForegroundColor Green
} catch {
    Write-Warning "Could not enable ARR proxy automatically. Ensure Microsoft ARR 3.0 is installed, then enable Proxy in IIS Manager -> Server Node -> Application Request Routing Cache -> Server Proxy Settings."
}

try {
    $existingVars = Get-WebConfigurationProperty -PSPath 'MACHINE/WEBROOT/APPHOST' -Filter "system.webServer/rewrite/allowedServerVariables" -Name "." |
        Select-Object -ExpandProperty Collection |
        Select-Object -ExpandProperty name -ErrorAction SilentlyContinue
    if ($existingVars -notcontains "HTTP_X_FORWARDED_PROTO") {
        Add-WebConfigurationProperty -PSPath 'MACHINE/WEBROOT/APPHOST' -Filter "system.webServer/rewrite/allowedServerVariables" -Name "." -Value @{ name = "HTTP_X_FORWARDED_PROTO" }
        Write-Host "[OK] Added HTTP_X_FORWARDED_PROTO to IIS allowedServerVariables." -ForegroundColor Green
    } else {
        Write-Host "[OK] HTTP_X_FORWARDED_PROTO already in IIS allowedServerVariables."
    }
} catch {
    Write-Warning "Could not add HTTP_X_FORWARDED_PROTO to allowedServerVariables. Ensure IIS URL Rewrite 2.1 is installed."
}

Write-Host ""
Write-Host "=== Bootstrap complete! ===" -ForegroundColor Cyan
Write-Host "Next steps:"
Write-Host "  1. Place your .env files in:"
Write-Host "       - $DeployRoot\backend\.env"
Write-Host "       - $DeployRoot\Services\KYCValidator\.env"
Write-Host "       - $DeployRoot\Services\AudiobookWorker\.env"
Write-Host "  2. Bind SSL/HTTPS certificates to $FrontendSite, $AdminSite, and $BackendSite in IIS Manager (e.g. via win-acme)."
Write-Host "  3. Ensure the GitHub Actions self-hosted runner service runs under an account with Administrator privileges so it can deploy to C:\inetpub and restart Windows Services."
