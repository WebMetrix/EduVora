<#
.SYNOPSIS
    Creates all EduVora GitHub Actions CI/CD, IIS, PM2, and PowerShell deployment files
    in the current directory (run this from your webmetrix/eduvora repository root).
#>
$ErrorActionPreference = "Stop"

function Write-RepoFile {
    param([string]$RelPath, [string]$Content)
    $fullPath = Join-Path (Get-Location) $RelPath
    $parent = Split-Path -Parent $fullPath
    if (-not (Test-Path $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
    Set-Content -Path $fullPath -Value $Content -Encoding UTF8
    Write-Host "[CREATED] $RelPath" -ForegroundColor Green
}

Write-RepoFile -RelPath ".github\workflows\ci-cd-iis.yml" -Content @'
name: EduVora CI/CD to Windows IIS

on:
  push:
    branches:
      - qa
      - main
  workflow_dispatch:
    inputs:
      environment:
        description: "Target deployment environment"
        required: true
        default: "qa"
        type: choice
        options:
          - qa
          - production
      component:
        description: "Component(s) to deploy"
        required: true
        default: "all"
        type: choice
        options:
          - all
          - frontend
          - admin_frontend
          - backend
          - kyc-python-worker
          - audiobook-worker

concurrency:
  group: eduvora-iis-deploy-${{ github.event.inputs.environment || (github.ref == 'refs/heads/main' && 'production' || 'qa') }}
  cancel-in-progress: false

jobs:
  deploy:
    name: Build & Deploy (${{ github.event.inputs.environment || (github.ref == 'refs/heads/main' && 'production' || 'qa') }})
    runs-on: [self-hosted, windows]
    environment: ${{ github.event.inputs.environment || (github.ref == 'refs/heads/main' && 'production' || 'qa') }}

    env:
      DEPLOY_ENV: ${{ github.event.inputs.environment || (github.ref == 'refs/heads/main' && 'production' || 'qa') }}
      DEPLOY_COMPONENT: ${{ github.event.inputs.component || 'all' }}
      DEPLOY_ROOT: ${{ vars.DEPLOY_ROOT || (github.ref == 'refs/heads/main' && 'C:\inetpub\EduVora\Prod' || 'C:\inetpub\EduVora\QA') }}
      BACKEND_PORT: ${{ vars.BACKEND_PORT || (github.ref == 'refs/heads/main' && '5000' || '5001') }}
      PM2_APP_NAME: ${{ vars.PM2_APP_NAME || (github.ref == 'refs/heads/main' && 'eduvora-backend-prod' || 'eduvora-backend-qa') }}
      IIS_FRONTEND_SITE: ${{ vars.IIS_FRONTEND_SITE || (github.ref == 'refs/heads/main' && 'EduVora-Frontend-Prod' || 'EduVora-Frontend-QA') }}
      IIS_ADMIN_SITE: ${{ vars.IIS_ADMIN_SITE || (github.ref == 'refs/heads/main' && 'EduVora-Admin-Prod' || 'EduVora-Admin-QA') }}
      IIS_BACKEND_SITE: ${{ vars.IIS_BACKEND_SITE || (github.ref == 'refs/heads/main' && 'EduVora-API-Prod' || 'EduVora-API-QA') }}
      KYC_SERVICE_NAME: ${{ vars.KYC_SERVICE_NAME || (github.ref == 'refs/heads/main' && 'EduVoraKYCValidator' || 'EduVoraKYCValidatorQA') }}
      AUDIOBOOK_SERVICE_NAME: ${{ vars.AUDIOBOOK_SERVICE_NAME || (github.ref == 'refs/heads/main' && 'EduVoraAudiobookWorker' || 'EduVoraAudiobookWorkerQA') }}

    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Verify toolchain on self-hosted Windows runner
        shell: pwsh
        run: |
          Write-Host "Environment : $env:DEPLOY_ENV"
          Write-Host "Component   : $env:DEPLOY_COMPONENT"
          Write-Host "Deploy Root : $env:DEPLOY_ROOT"
          node -v
          npm -v
          pm2 -v
          python --version

      - name: Build Frontend (Vite + React)
        if: env.DEPLOY_COMPONENT == 'all' || env.DEPLOY_COMPONENT == 'frontend'
        working-directory: frontend
        shell: pwsh
        env:
          VITE_API_URL: ${{ vars.VITE_API_URL }}
          VITE_REFERRAL_URL: ${{ vars.VITE_REFERRAL_URL }}
          VITE_FALLBACK_PROF_PICTURE: ${{ vars.VITE_FALLBACK_PROF_PICTURE }}
          VITE_MIN_WITHDRAWAL_AMOUNT: ${{ vars.VITE_MIN_WITHDRAWAL_AMOUNT }}
          VITE_GOOGLE_CLIENT_ID: ${{ secrets.VITE_GOOGLE_CLIENT_ID }}
          VITE_CRYPTO_SECRET: ${{ secrets.VITE_CRYPTO_SECRET }}
        run: |
          npm ci
          npm run build

      - name: Build Admin Frontend (Vite + React)
        if: env.DEPLOY_COMPONENT == 'all' || env.DEPLOY_COMPONENT == 'admin_frontend'
        working-directory: admin_frontend
        shell: pwsh
        env:
          VITE_API_URL: ${{ vars.ADMIN_VITE_API_URL || vars.VITE_API_URL }}
        run: |
          npm ci
          npm run build

      - name: Deploy selected components to IIS, PM2, and Windows Services
        shell: pwsh
        run: |
          & "$env:GITHUB_WORKSPACE\deploy\scripts\deploy-all.ps1" `
            -SourceRoot "$env:GITHUB_WORKSPACE" `
            -DeployRoot "$env:DEPLOY_ROOT" `
            -Environment "$env:DEPLOY_ENV" `
            -Component "$env:DEPLOY_COMPONENT" `
            -BackendPort ([int]$env:BACKEND_PORT) `
            -Pm2AppName "$env:PM2_APP_NAME" `
            -IisFrontendSite "$env:IIS_FRONTEND_SITE" `
            -IisAdminSite "$env:IIS_ADMIN_SITE" `
            -IisBackendSite "$env:IIS_BACKEND_SITE" `
            -KycServiceName "$env:KYC_SERVICE_NAME" `
            -AudiobookServiceName "$env:AUDIOBOOK_SERVICE_NAME"
'@

Write-RepoFile -RelPath "deploy\iis\frontend-web.config" -Content @'
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
  <system.webServer>
    <rewrite>
      <rules>
        <rule name="React Router SPA Fallback" stopProcessing="true">
          <match url=".*" />
          <conditions logicalGrouping="MatchAll">
            <add input="{REQUEST_FILENAME}" matchType="IsFile" negate="true" />
            <add input="{REQUEST_FILENAME}" matchType="IsDirectory" negate="true" />
          </conditions>
          <action type="Rewrite" url="/index.html" />
        </rule>
      </rules>
    </rewrite>

    <staticContent>
      <remove fileExtension=".json" />
      <mimeMap fileExtension=".json" mimeType="application/json" />
      <remove fileExtension=".webp" />
      <mimeMap fileExtension=".webp" mimeType="image/webp" />
      <remove fileExtension=".woff2" />
      <mimeMap fileExtension=".woff2" mimeType="font/woff2" />
    </staticContent>

    <httpProtocol>
      <customHeaders>
        <remove name="X-Powered-By" />
        <add name="X-Content-Type-Options" value="nosniff" />
        <add name="X-Frame-Options" value="SAMEORIGIN" />
        <add name="Referrer-Policy" value="strict-origin-when-cross-origin" />
      </customHeaders>
    </httpProtocol>
  </system.webServer>
</configuration>
'@

Write-RepoFile -RelPath "deploy\iis\admin-frontend-web.config" -Content @'
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
  <system.webServer>
    <rewrite>
      <rules>
        <rule name="Admin React Router SPA Fallback" stopProcessing="true">
          <match url=".*" />
          <conditions logicalGrouping="MatchAll">
            <add input="{REQUEST_FILENAME}" matchType="IsFile" negate="true" />
            <add input="{REQUEST_FILENAME}" matchType="IsDirectory" negate="true" />
          </conditions>
          <action type="Rewrite" url="/index.html" />
        </rule>
      </rules>
    </rewrite>

    <staticContent>
      <remove fileExtension=".json" />
      <mimeMap fileExtension=".json" mimeType="application/json" />
      <remove fileExtension=".webp" />
      <mimeMap fileExtension=".webp" mimeType="image/webp" />
      <remove fileExtension=".woff2" />
      <mimeMap fileExtension=".woff2" mimeType="font/woff2" />
    </staticContent>

    <httpProtocol>
      <customHeaders>
        <remove name="X-Powered-By" />
        <add name="X-Content-Type-Options" value="nosniff" />
        <add name="X-Frame-Options" value="DENY" />
        <add name="Referrer-Policy" value="strict-origin-when-cross-origin" />
      </customHeaders>
    </httpProtocol>
  </system.webServer>
</configuration>
'@

Write-RepoFile -RelPath "deploy\iis\backend-web.config.template" -Content @'
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
  <system.webServer>
    <!-- Allow uploads up to 100 MB (KYC documents, avatars, chapter PDFs via Multer) -->
    <security>
      <requestFiltering>
        <requestLimits maxAllowedContentLength="104857600" />
      </requestFiltering>
    </security>

    <!-- Reverse proxy all API requests to the local PM2-managed Node.js Express server -->
    <rewrite>
      <rules>
        <rule name="ReverseProxyToEduVoraBackend" stopProcessing="true">
          <match url="(.*)" />
          <action type="Rewrite" url="http://127.0.0.1:__BACKEND_PORT__/{R:1}" appendQueryString="true" />
          <serverVariables>
            <set name="HTTP_X_FORWARDED_PROTO" value="https" replace="false" />
          </serverVariables>
        </rule>
      </rules>
    </rewrite>

    <httpProtocol>
      <customHeaders>
        <remove name="X-Powered-By" />
      </customHeaders>
    </httpProtocol>
  </system.webServer>
</configuration>
'@

Write-RepoFile -RelPath "deploy\pm2\ecosystem.config.cjs" -Content @'
// Note: .cjs extension is required because backend/package.json uses "type": "module" (ESM).
module.exports = {
  apps: [
    {
      name: process.env.PM2_APP_NAME || "eduvora-backend-qa",
      script: "app.js",
      cwd: process.env.BACKEND_DIR || "C:\\inetpub\\EduVora\\QA\\backend",
      exec_mode: "fork",
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: "1G",
      env: {
        NODE_ENV: process.env.NODE_ENV || "development",
        PORT: process.env.PORT || "5001"
      },
      env_qa: {
        NODE_ENV: "qa",
        PORT: process.env.PORT || "5001"
      },
      env_production: {
        NODE_ENV: "production",
        PORT: process.env.PORT || "5000"
      },
      out_file: (process.env.BACKEND_DIR || "C:\\inetpub\\EduVora\\QA\\backend") + "\\logs\\pm2-out.log",
      error_file: (process.env.BACKEND_DIR || "C:\\inetpub\\EduVora\\QA\\backend") + "\\logs\\pm2-error.log",
      merge_logs: true,
      time: true
    }
  ]
};
'@

Write-RepoFile -RelPath "deploy\scripts\setup-server.ps1" -Content @'
<#
.SYNOPSIS
    One-time Windows Server + IIS bootstrap script for EduVora (QA or Production).
    MUST be run as Administrator in PowerShell.

.EXAMPLE
    .\setup-server.ps1 -Environment qa -DeployRoot "C:\inetpub\EduVora\QA" `
        -FrontendHost "eduvoraqa.eduvora.co.in" `
        -AdminHost "adminqa.eduvora.co.in" `
        -ApiHost "apiqa.eduvora.co.in"
#>
[CmdletBinding()]
param(
    [ValidateSet("qa", "production")]
    [string]$Environment = "qa",

    [string]$DeployRoot = "C:\inetpub\EduVora\QA",

    [string]$FrontendSite = "EduVora-Frontend-QA",
    [string]$AdminSite    = "EduVora-Admin-QA",
    [string]$BackendSite  = "EduVora-API-QA",

    [string]$FrontendHost = "eduvoraqa.eduvora.co.in",
    [string]$AdminHost    = "adminqa.eduvora.co.in",
    [string]$ApiHost      = "apiqa.eduvora.co.in",

    [int]$HttpPort = 80
)

$ErrorActionPreference = "Stop"

# Verify Administrator privileges
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Please run this script in an elevated PowerShell window (Run as Administrator)."
}

Write-Host "=== Bootstrapping EduVora ($Environment) at $DeployRoot ===" -ForegroundColor Cyan

# 1. Verify required tools
foreach ($cmd in @("node", "npm", "pm2", "python")) {
    if (-not (Get-Command $cmd -ErrorAction SilentlyContinue)) {
        Write-Warning "Command '$cmd' was not found in PATH. Install it before running the CI/CD pipeline."
    } else {
        Write-Host "[OK] Found $cmd -> $((Get-Command $cmd).Source)" -ForegroundColor Green
    }
}

# 2. Create directory layout
$dirs = @(
    "$DeployRoot\frontend",
    "$DeployRoot\admin_frontend",
    "$DeployRoot\backend",
    "$DeployRoot\backend\logs",
    "$DeployRoot\backend\App_Data",
    "$DeployRoot\Services\KYCValidator",
    "$DeployRoot\Services\KYCValidator\logs",
    "$DeployRoot\Services\AudiobookWorker",
    "$DeployRoot\Services\AudiobookWorker\logs"
)
foreach ($d in $dirs) {
    if (-not (Test-Path $d)) {
        New-Item -ItemType Directory -Path $d -Force | Out-Null
        Write-Host "[CREATED] $d"
    }
}

# 3. Configure IIS Sites & AppPools
Import-Module WebAdministration

function Ensure-IisSite {
    param(
        [string]$SiteName,
        [string]$PhysicalPath,
        [string]$HostHeader,
        [int]$Port
    )

    $poolName = "$SiteName-Pool"
    if (-not (Test-Path "IIS:\AppPools\$poolName")) {
        New-WebAppPool -Name $poolName | Out-Null
        # Static SPAs and Reverse Proxy sites do not need .NET CLR
        Set-ItemProperty "IIS:\AppPools\$poolName" -Name managedRuntimeVersion -Value ""
        Write-Host "[CREATED] AppPool $poolName (No Managed Code)" -ForegroundColor Green
    }

    if (-not (Test-Path "IIS:\Sites\$SiteName")) {
        New-Website -Name $SiteName -PhysicalPath $PhysicalPath -ApplicationPool $poolName -Port $Port -HostHeader $HostHeader | Out-Null
        Write-Host "[CREATED] IIS Site $SiteName ($HostHeader`:$Port -> $PhysicalPath)" -ForegroundColor Green
    } else {
        Set-ItemProperty "IIS:\Sites\$SiteName" -Name physicalPath -Value $PhysicalPath
        Write-Host "[EXISTS]  IIS Site $SiteName updated physicalPath -> $PhysicalPath"
    }
}

Ensure-IisSite -SiteName $FrontendSite -PhysicalPath "$DeployRoot\frontend"       -HostHeader $FrontendHost -Port $HttpPort
Ensure-IisSite -SiteName $AdminSite    -PhysicalPath "$DeployRoot\admin_frontend" -HostHeader $AdminHost    -Port $HttpPort
Ensure-IisSite -SiteName $BackendSite  -PhysicalPath "$DeployRoot\backend"        -HostHeader $ApiHost      -Port $HttpPort

# 4. Enable IIS ARR Reverse Proxy & allow HTTP_X_FORWARDED_PROTO server variable
try {
    Set-WebConfigurationProperty -PSPath 'MACHINE/WEBROOT/APPHOST' -Filter "system.webServer/proxy" -Name "enabled" -Value "True"
    Write-Host "[OK] Enabled IIS ARR server proxy." -ForegroundColor Green
} catch {
    Write-Warning "Could not enable ARR proxy automatically. Ensure Microsoft ARR 3.0 is installed, then enable Proxy in IIS Manager -> Server Node -> Application Request Routing Cache -> Server Proxy Settings."
}

try {
    $existingVars = Get-WebConfigurationProperty -PSPath 'MACHINE/WEBROOT/APPHOST' -Filter "system.webServer/rewrite/allowedServerVariables" -Name "." |
        Select-Object -ExpandProperty Collection |
        Select-Object -ExpandProperty name -ErrorAction SilentlyContinue
    if ($existingVars -notcontains "HTTP_X_FORWARDED_PROTO") {
        Add-WebConfigurationProperty -PSPath 'MACHINE/WEBROOT/APPHOST' -Filter "system.webServer/rewrite/allowedServerVariables" -Name "." -Value @{ name = "HTTP_X_FORWARDED_PROTO" }
        Write-Host "[OK] Added HTTP_X_FORWARDED_PROTO to IIS allowedServerVariables." -ForegroundColor Green
    } else {
        Write-Host "[OK] HTTP_X_FORWARDED_PROTO already in IIS allowedServerVariables."
    }
} catch {
    Write-Warning "Could not add HTTP_X_FORWARDED_PROTO to allowedServerVariables. Ensure IIS URL Rewrite 2.1 is installed."
}

Write-Host ""
Write-Host "=== Bootstrap complete! ===" -ForegroundColor Cyan
Write-Host "Next steps:"
Write-Host "  1. Place your .env files in:"
Write-Host "       - $DeployRoot\backend\.env"
Write-Host "       - $DeployRoot\Services\KYCValidator\.env"
Write-Host "       - $DeployRoot\Services\AudiobookWorker\.env"
Write-Host "  2. Bind SSL/HTTPS certificates to $FrontendSite, $AdminSite, and $BackendSite in IIS Manager (e.g. via win-acme)."
Write-Host "  3. Ensure the GitHub Actions self-hosted runner service runs under an account with Administrator privileges so it can deploy to C:\inetpub and restart Windows Services."
'@

Write-RepoFile -RelPath "deploy\scripts\deploy-all.ps1" -Content @'
<#
.SYNOPSIS
    Idempotent deployment script for all 5 EduVora components on Windows Server:
      1. frontend          -> IIS static SPA + URL Rewrite web.config
      2. admin_frontend    -> IIS static SPA + URL Rewrite web.config
      3. backend           -> Node.js Express 5 ESM managed by PM2 + IIS ARR Reverse Proxy web.config
      4. kyc-python-worker -> Python Celery native Windows Service (EduVoraKYCValidator*)
      5. audiobook-worker  -> Python Celery native Windows Service (EduVoraAudiobookWorker*)
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$SourceRoot,

    [Parameter(Mandatory = $true)]
    [string]$DeployRoot,

    [ValidateSet("qa", "production")]
    [string]$Environment = "qa",

    [ValidateSet("all", "frontend", "admin_frontend", "backend", "kyc-python-worker", "audiobook-worker")]
    [string]$Component = "all",

    [int]$BackendPort = 5001,
    [string]$Pm2AppName = "eduvora-backend-qa",
    [string]$IisFrontendSite = "EduVora-Frontend-QA",
    [string]$IisAdminSite = "EduVora-Admin-QA",
    [string]$IisBackendSite = "EduVora-API-QA",
    [string]$KycServiceName = "EduVoraKYCValidatorQA",
    [string]$AudiobookServiceName = "EduVoraAudiobookWorkerQA"
)

$ErrorActionPreference = "Stop"

function Invoke-RobocopyMirror {
    param(
        [string]$Source,
        [string]$Destination,
        [string[]]$ExcludeDirs = @(),
        [string[]]$ExcludeFiles = @()
    )

    if (-not (Test-Path $Destination)) {
        New-Item -ItemType Directory -Path $Destination -Force | Out-Null
    }

    $argsList = @($Source, $Destination, "/MIR", "/R:3", "/W:2", "/NFL", "/NDL", "/NP")
    if ($ExcludeDirs.Count -gt 0) {
        $argsList += "/XD"
        $argsList += $ExcludeDirs
    }
    if ($ExcludeFiles.Count -gt 0) {
        $argsList += "/XF"
        $argsList += $ExcludeFiles
    }

    & robocopy @argsList | Out-Host
    # Robocopy exit codes 0-7 indicate success; 8+ indicate errors
    if ($LASTEXITCODE -ge 8) {
        throw "Robocopy failed with exit code $LASTEXITCODE ($Source -> $Destination)"
    }
    $global:LASTEXITCODE = 0
}

function Stop-WinServiceSafe {
    param([string]$ServiceName)
    $svc = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    if ($null -ne $svc) {
        if ($svc.Status -ne "Stopped") {
            Write-Host "Stopping Windows Service '$ServiceName'..."
            Stop-Service -Name $ServiceName -Force -ErrorAction Stop
            $svc.WaitForStatus("Stopped", [TimeSpan]::FromSeconds(30))
        }
        return $true
    }
    return $false
}

function Start-WinServiceSafe {
    param([string]$ServiceName)
    Write-Host "Starting Windows Service '$ServiceName'..."
    Start-Service -Name $ServiceName -ErrorAction Stop
    $svc = Get-Service -Name $ServiceName
    $svc.WaitForStatus("Running", [TimeSpan]::FromSeconds(30))
    Write-Host "[OK] Windows Service '$ServiceName' is Running." -ForegroundColor Green
}

function Deploy-StaticSpa {
    param(
        [string]$Label,
        [string]$DistPath,
        [string]$TargetDir,
        [string]$WebConfigSource
    )

    Write-Host "`n=== Deploying $Label -> $TargetDir ===" -ForegroundColor Cyan
    if (-not (Test-Path $DistPath)) {
        throw "Build output not found at $DistPath. Ensure 'npm run build' ran before deploy."
    }

    Invoke-RobocopyMirror -Source $DistPath -Destination $TargetDir -ExcludeFiles @("web.config")
    Copy-Item -Path $WebConfigSource -Destination (Join-Path $TargetDir "web.config") -Force
    Write-Host "[OK] $Label deployed with IIS web.config." -ForegroundColor Green
}

function Deploy-Backend {
    $srcDir = Join-Path $SourceRoot "backend"
    $dstDir = Join-Path $DeployRoot "backend"
    Write-Host "`n=== Deploying Backend (PM2 + IIS Reverse Proxy) -> $dstDir ===" -ForegroundColor Cyan

    if (-not (Test-Path (Join-Path $dstDir ".env"))) {
        Write-Warning "No .env file found at $dstDir\.env. Create it on the server with DB, RabbitMQ, Cashfree, JWT, and PORT=$BackendPort settings."
    }

    # Preserve server-side secrets, runtime uploads, logs, and node_modules during sync
    Invoke-RobocopyMirror -Source $srcDir -Destination $dstDir `
        -ExcludeDirs @("node_modules", "logs", "App_Data", ".git") `
        -ExcludeFiles @(".env", "web.config", "ecosystem.config.cjs")

    # Install production dependencies
    Push-Location $dstDir
    try {
        Write-Host "Installing production npm dependencies..."
        npm ci --omit=dev
        if ($LASTEXITCODE -ne 0) { throw "npm ci --omit=dev failed in $dstDir" }
    } finally {
        Pop-Location
    }

    # Render IIS reverse-proxy web.config with target port
    $tplPath = Join-Path $SourceRoot "deploy\iis\backend-web.config.template"
    $webConfigContent = (Get-Content -Path $tplPath -Raw).Replace("__BACKEND_PORT__", $BackendPort.ToString())
    Set-Content -Path (Join-Path $dstDir "web.config") -Value $webConfigContent -Encoding UTF8

    # Copy PM2 ecosystem.config.cjs
    Copy-Item -Path (Join-Path $SourceRoot "deploy\pm2\ecosystem.config.cjs") `
              -Destination (Join-Path $dstDir "ecosystem.config.cjs") -Force

    # Start or reload via PM2
    $env:PM2_APP_NAME = $Pm2AppName
    $env:BACKEND_DIR  = $dstDir
    $env:PORT         = $BackendPort.ToString()
    $env:NODE_ENV     = $Environment

    Push-Location $dstDir
    try {
        $pm2EnvFlag = if ($Environment -eq "production") { "production" } else { "qa" }
        Write-Host "Reloading PM2 app '$Pm2AppName' (port $BackendPort, env $pm2EnvFlag)..."
        pm2 startOrReload ecosystem.config.cjs --env $pm2EnvFlag --update-env
        if ($LASTEXITCODE -ne 0) { throw "pm2 startOrReload failed for $Pm2AppName" }
        pm2 save
    } finally {
        Pop-Location
    }

    # Health check local Express listener
    Start-Sleep -Seconds 3
    $healthUrl = "http://127.0.0.1:$BackendPort/api-docs"
    try {
        $resp = Invoke-WebRequest -Uri $healthUrl -UseBasicParsing -TimeoutSec 10
        Write-Host "[OK] Backend health check succeeded ($healthUrl -> HTTP $($resp.StatusCode))." -ForegroundColor Green
    } catch {
        # Express responding with 401/404 still proves the server is up and accepting HTTP traffic
        if ($_.Exception.Response) {
            $code = [int]$_.Exception.Response.StatusCode
            Write-Host "[OK] Backend listener is active ($healthUrl -> HTTP $code)." -ForegroundColor Green
        } else {
            throw "Backend health check failed on $healthUrl : $($_.Exception.Message)"
        }
    }
}

function Deploy-PythonWorker {
    param(
        [string]$Label,
        [string]$SourceSubdir,
        [string]$TargetDir,
        [string]$ServiceName,
        [bool]$EnsurePyWin32 = $true,
        [bool]$PatchKycBatToVenv = $false
    )

    $srcDir = Join-Path $SourceRoot $SourceSubdir
    Write-Host "`n=== Deploying $Label ($ServiceName) -> $TargetDir ===" -ForegroundColor Cyan

    $serviceExisted = Stop-WinServiceSafe -ServiceName $ServiceName

    # Sync worker source while preserving .env, .venv, and logs
    Invoke-RobocopyMirror -Source $srcDir -Destination $TargetDir `
        -ExcludeDirs @(".venv", "venv", "logs", "__pycache__", ".git") `
        -ExcludeFiles @(".env")

    if (-not (Test-Path (Join-Path $TargetDir ".env"))) {
        Write-Warning "No .env file found at $TargetDir\.env. Worker service may fail to start until .env is created."
    }

    $venvDir   = Join-Path $TargetDir ".venv"
    $pythonExe = Join-Path $venvDir "Scripts\python.exe"

    if (-not (Test-Path $pythonExe)) {
        Write-Host "Creating Python virtual environment at $venvDir..."
        python -m venv $venvDir
        if ($LASTEXITCODE -ne 0) { throw "Failed to create Python venv at $venvDir" }
    }

    Write-Host "Installing Python dependencies from requirements.txt..."
    & $pythonExe -m pip install --upgrade pip
    & $pythonExe -m pip install -r (Join-Path $TargetDir "requirements.txt")
    if ($LASTEXITCODE -ne 0) { throw "pip install failed for $Label" }

    if ($EnsurePyWin32) {
        & $pythonExe -m pip install pywin32
        $postInstall = Join-Path $venvDir "Scripts\pywin32_postinstall.py"
        if (Test-Path $postInstall) {
            & $pythonExe $postInstall -install -silent
        }
    }

    # Ensure KYC run_worker.bat uses the isolated .venv Python and correct working directory
    if ($PatchKycBatToVenv) {
        $batPath = Join-Path $TargetDir "run_worker.bat"
        $batContent = @"
@echo off
cd /d "%~dp0"
echo Starting EduVora KYC Celery Worker...
"%~dp0.venv\Scripts\python.exe" -m celery -A worker_app.celery_app worker --loglevel=info --pool=solo --without-mingle --without-gossip
"@
        Set-Content -Path $batPath -Value $batContent -Encoding ASCII

        # Patch windows_service.py if TargetDir or ServiceName differs from hardcoded default
        $svcScript = Join-Path $TargetDir "windows_service.py"
        if (Test-Path $svcScript) {
            $pyText = Get-Content -Path $svcScript -Raw
            $pyText = $pyText -replace '_svc_name_\s*=\s*"[^"]+"', "_svc_name_ = `"$ServiceName`""
            $pyText = $pyText -replace 'r"C:\\inetpub\\EduVora\\Services\\KYCValidator\\run_worker\.bat"', "r`"$batPath`""
            $pyText = $pyText -replace 'r"C:\\inetpub\\EduVora\\Services\\KYCValidator"', "r`"$TargetDir`""
            Set-Content -Path $svcScript -Value $pyText -Encoding UTF8
        }
    }

    # Install Windows Service if not yet registered
    if (-not $serviceExisted) {
        Write-Host "Installing Windows Service '$ServiceName' for the first time..."
        Push-Location $TargetDir
        try {
            & $pythonExe (Join-Path $TargetDir "windows_service.py") --startup auto install
            if ($LASTEXITCODE -ne 0) { throw "Failed to install Windows Service $ServiceName" }
            sc.exe failure $ServiceName reset= 86400 actions= restart/10000/restart/30000/restart/60000 | Out-Null
        } finally {
            Pop-Location
        }
    }

    Start-WinServiceSafe -ServiceName $ServiceName
}

# --- Execute selected deployments ---
if ($Component -in @("all", "frontend")) {
    Deploy-StaticSpa -Label "Frontend" `
        -DistPath (Join-Path $SourceRoot "frontend\dist") `
        -TargetDir (Join-Path $DeployRoot "frontend") `
        -WebConfigSource (Join-Path $SourceRoot "deploy\iis\frontend-web.config")
}

if ($Component -in @("all", "admin_frontend")) {
    Deploy-StaticSpa -Label "Admin Frontend" `
        -DistPath (Join-Path $SourceRoot "admin_frontend\dist") `
        -TargetDir (Join-Path $DeployRoot "admin_frontend") `
        -WebConfigSource (Join-Path $SourceRoot "deploy\iis\admin-frontend-web.config")
}

if ($Component -in @("all", "backend")) {
    Deploy-Backend
}

if ($Component -in @("all", "kyc-python-worker")) {
    Deploy-PythonWorker -Label "KYC Python Worker" `
        -SourceSubdir "kyc-python-worker" `
        -TargetDir (Join-Path $DeployRoot "Services\KYCValidator") `
        -ServiceName $KycServiceName `
        -EnsurePyWin32 $true `
        -PatchKycBatToVenv $true
}

if ($Component -in @("all", "audiobook-worker")) {
    Deploy-PythonWorker -Label "Audiobook Worker" `
        -SourceSubdir "audiobook-worker" `
        -TargetDir (Join-Path $DeployRoot "Services\AudiobookWorker") `
        -ServiceName $AudiobookServiceName `
        -EnsurePyWin32 $true `
        -PatchKycBatToVenv $false
}

Write-Host "`n=== EduVora deployment ($Environment / $Component) completed successfully! ===" -ForegroundColor Green
'@

Write-Host "`nAll EduVora CI/CD files have been created! Commit and push them to trigger the workflow." -ForegroundColor Cyan
